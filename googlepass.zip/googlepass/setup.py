from setuptools import find_packages, setup
setup(
    name='passgenerator',
    packages=find_packages(include=['passgenerator']),
    version='0.1.0',
    description='Google Pass Generator',
    author='Me',
    license='MIT',
    install_requires=[],
    setup_requires=['pytest-runner'],
)